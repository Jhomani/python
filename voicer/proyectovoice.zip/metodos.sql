DROP TABLE IF EXISTS `Cliente`, `Producto`; 

CREATE TABLE `Cliente` (
  `id` bigint PRIMARY KEY NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `direccion` varchar(55) NOT NULL,
  `movil` varchar(50) NOT NULL
);

CREATE TABLE `Producto` (
  `id` bigint PRIMARY KEY NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `precio` int,
  `cantidad` int,
  `categoria` varchar(50)
);

INSERT INTO `Cliente` (`name`, `direccion`, `movil`) VALUES 
  ("Rodrigo", "Cochambaba", "35342425"), 
  ("Juan", "La Paz", "35342425"), 
  ("Ramiro", "La Paz", "35342425"), 
  ("Carlos", "Cuero", "35342425"), 
  ("Rodrigo", "Mascotas", "35342425"),
  ("Maria", "Mascotas", "35342425"),
  ("Carolina", "Mascotas", "35342425");

INSERT INTO `Producto` (`name`, `precio`, `cantidad`, `categoria`) VALUES 
  ("Window",42, 535, "soft"), 
  ("Parlantes", 53, 63, "hard"), 
  ("Mouse",425,435, "hard"), 
  ("Laptop", 535,3653, "hard"), 
  ("Arch",425,53, "soft");